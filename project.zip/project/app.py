import streamlit as st
import pandas as pd

#페이지 명칭 설정
st.set_page_config(page_title="Escape from Tarkov 아이템(item)", layout="wide")
st.title("Escape from Tarkov 아이템(item)")

# 페이지 상태 초기화(현재 사용X)
if "page" not in st.session_state:
    st.session_state["page"] = "item"   # item / source
    st.session_state["source_id"] = None
    st.session_state["source_name"] = None

if "selected_item_id" not in st.session_state:
    st.session_state["selected_item_id"] = None

# 데이터 로드
@st.cache_data
def load_data():
    return pd.read_csv("items.csv")

@st.cache_data
def load_looting():
    return pd.read_csv("looting.csv")

df = load_data()
looting_df = load_looting()

#페이지 전환용 함수(현재 사용X)
def show_item_page():
    pass

def show_source_page():
    pass

if st.session_state["page"] == "item":
    show_item_page()
elif st.session_state["page"] == "source":
    show_source_page()

# 획득처 초기화(버튼)
if "selected_source" not in st.session_state:
    st.session_state["selected_source"] = None
    st.session_state["selected_source_name"] = None

# 검색
keyword = st.text_input("아이템 이름 검색")

# 검색 시 아이템 필터링(아이템 이름 포함 표시, 대소문자 무시, 조건 없을시 전체 표시)
if st.session_state["selected_item_id"]:
    view_df = df[df["item_id"] == st.session_state["selected_item_id"]]
elif keyword:
    view_df = df[df["name"].str.contains(keyword, case=False, na=False)]
else:
    view_df = df

# 아이템 UI(박스) 
for _, item in view_df.iterrows():
    with st.expander(item["name"]):

# 컬럼 분할
        col1, col2 = st.columns([1, 5])
        
# 이미지 표시
        with col1:
            st.markdown("🖼️")

# 아이템 이름
        with col2:
            st.text(item["name"])

# 아이템 정보 
        flea_value = str(item.get("flea_market_sellable", "")).upper()
        flea_text = "🟢 가능" if flea_value == "TRUE" else "🔴 불가"

        st.markdown(f"""
**무게** : {item['weight']} kg  
**크기** : {item['size']}  
**폴리마켓** : {flea_text}
""")

        st.divider()

# 아이템 획득처   
        st.subheader("획득처")

        item_loot = looting_df[looting_df["item_id"] == item["item_id"]]

        if item_loot.empty:
            st.caption("데이터 없음")
        else:
            for _, loot in item_loot.iterrows():
                label = f"{loot['source_name']} ({loot['rarity']})"

                if st.button(
                    label,
                    key=f"{item['item_id']}_{loot['source_id']}"
                ):
                    st.session_state["selected_source"] = loot["source_id"]
                    st.session_state["selected_source_name"] = loot["source_name"]
           

        st.divider()

# 아이템 사용(교환)
        st.subheader("사용처")

        try:
            barters_df = pd.read_csv("barters.csv")
            barter_items_df = pd.read_csv("barters_items.csv")
        except:
            barters_df = pd.DataFrame()
            barter_items_df = pd.DataFrame()

# 현재 아이템이 들어가는 교환 찾기
        used_in_barters = barter_items_df[
            barter_items_df["item_id"] == item["item_id"]
        ]

        if used_in_barters.empty:
            st.caption("데이터 없음")
        else:
            st.markdown("▶ **교환**")
            
# 출력
            for barter_id in used_in_barters["barter_id"].unique():
                barter_info = barters_df[
                    barters_df["barter_id"] == barter_id
                ].iloc[0]

                required_items = barter_items_df[
                    barter_items_df["barter_id"] == barter_id
                ]

                req_texts = []
                for _, req in required_items.iterrows():
                    req_texts.append(
                       f"{req['item_name']} x{int(req['quantity'])}"
                    )

                req_text = " + ".join(req_texts)

                result_text = f"{barter_info['result_item_id']} x{int(barter_info['result_quantity'])}"

                st.markdown(
                    f"{req_text} → **{result_text}**"
                )

                st.caption(
                    f"상인 : {barter_info['trader_name']}  \n"
                    f"해금조건 : {barter_info['unlock_11']}"
                )

                st.markdown("---")


        st.divider()

        st.subheader("상점")
        st.caption("데이터 없음")
